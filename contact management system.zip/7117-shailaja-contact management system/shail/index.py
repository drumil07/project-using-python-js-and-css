from tkinter import *
import sqlite3
import tkinter.ttk as ttk
import tkinter.messagebox as tkMessageBox

root = Tk()
root.title("Contact Management System")
width = 700
height = 400
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x = (screen_width/2) - (width/2)
y = (screen_height/2) - (height/2)
root.geometry("%dx%d+%d+%d" % (width, height, x, y))
root.resizable(0, 0)
root.config(bg="#6666ff")

#============================VARIABLES===================================
FIRSTNAME = StringVar()
LASTNAME = StringVar()
CONTACT = StringVar()

#============================METHODS=====================================

def Database():
    conn = sqlite3.connect("contact.db")
    cursor = conn.cursor()
    cursor.execute("CREATE TABLE IF NOT EXISTS `member` (mem_id INTEGER PRIMARY KEY AUTOINCREMENT, firstname TEXT, lastname TEXT, contact TEXT)")
    cursor.execute("SELECT * FROM `member` ORDER BY `lastname` ASC")
    fetch = cursor.fetchall()
    for data in fetch:
        tree.insert('', 'end', values=(data))
    cursor.close()
    conn.close()

def SubmitData():
    if FIRSTNAME.get() == "" or LASTNAME.get() == "" or CONTACT.get() == "":
        tkMessageBox.showwarning('', 'Please Complete The Required Field', icon="warning")
    else:
        tree.delete(*tree.get_children())
        conn = sqlite3.connect("contact.db")
        cursor = conn.cursor()
        cursor.execute("INSERT INTO `member` (firstname, lastname, contact) VALUES (?, ?, ?)",
                       (FIRSTNAME.get(), LASTNAME.get(), CONTACT.get()))
        conn.commit()
        cursor.execute("SELECT * FROM `member` ORDER BY `lastname` ASC")
        fetch = cursor.fetchall()
        for data in fetch:
            tree.insert('', 'end', values=(data))
        cursor.close()
        conn.close()
        FIRSTNAME.set("")
        LASTNAME.set("")
        CONTACT.set("")

def UpdateData():
    tree.delete(*tree.get_children())
    conn = sqlite3.connect("contact.db")
    cursor = conn.cursor()
    cursor.execute("UPDATE `member` SET `firstname` = ?, `lastname` = ?, `contact` = ? WHERE `mem_id` = ?",
                   (FIRSTNAME.get(), LASTNAME.get(), CONTACT.get(), int(mem_id)))
    conn.commit()
    cursor.execute("SELECT * FROM `member` ORDER BY `lastname` ASC")
    fetch = cursor.fetchall()
    for data in fetch:
        tree.insert('', 'end', values=(data))
    cursor.close()
    conn.close()
    FIRSTNAME.set("")
    LASTNAME.set("")
    CONTACT.set("")

def OnSelected(event):
    global mem_id, UpdateWindow
    curItem = tree.focus()
    contents = tree.item(curItem)
    selecteditem = contents['values']
    mem_id = selecteditem[0]
    FIRSTNAME.set(selecteditem[1])
    LASTNAME.set(selecteditem[2])
    CONTACT.set(selecteditem[3])

    UpdateWindow = Toplevel()
    UpdateWindow.title("Update Contact")
    UpdateWindow.geometry("400x250")
    UpdateWindow.resizable(0, 0)

    FormTitle = Frame(UpdateWindow)
    FormTitle.pack(side=TOP)
    ContactForm = Frame(UpdateWindow)
    ContactForm.pack(side=TOP, pady=10)

    Label(FormTitle, text="Update Contact", font=('arial', 16), bg="orange", width=300).pack(fill=X)
    Label(ContactForm, text="Firstname", font=('arial', 14)).grid(row=0, sticky=W)
    Entry(ContactForm, textvariable=FIRSTNAME, font=('arial', 14)).grid(row=0, column=1)
    Label(ContactForm, text="Lastname", font=('arial', 14)).grid(row=1, sticky=W)
    Entry(ContactForm, textvariable=LASTNAME, font=('arial', 14)).grid(row=1, column=1)
    Label(ContactForm, text="Contact", font=('arial', 14)).grid(row=2, sticky=W)
    Entry(ContactForm, textvariable=CONTACT, font=('arial', 14)).grid(row=2, column=1)

    Button(ContactForm, text="Update", width=50, command=UpdateData).grid(row=3, columnspan=2, pady=10)

def DeleteData():
    if not tree.selection():
        tkMessageBox.showwarning('', 'Please Select Something First!', icon="warning")
    else:
        result = tkMessageBox.askquestion('', 'Are you sure you want to delete this record?', icon="warning")
        if result == 'yes':
            curItem = tree.focus()
            selecteditem = tree.item(curItem)['values']
            tree.delete(curItem)
            conn = sqlite3.connect("contact.db")
            cursor = conn.cursor()
            cursor.execute("DELETE FROM `member` WHERE `mem_id` = ?", (selecteditem[0],))
            conn.commit()
            cursor.close()
            conn.close()

def AddNewWindow():
    global NewWindow
    FIRSTNAME.set("")
    LASTNAME.set("")
    CONTACT.set("")
    NewWindow = Toplevel()
    NewWindow.title("Add New Contact")
    NewWindow.geometry("400x250")
    NewWindow.resizable(0, 0)

    FormTitle = Frame(NewWindow)
    FormTitle.pack(side=TOP)
    ContactForm = Frame(NewWindow)
    ContactForm.pack(side=TOP, pady=10)

    Label(FormTitle, text="Add New Contact", font=('arial', 16), bg="#66ff66", width=300).pack(fill=X)
    Label(ContactForm, text="Firstname", font=('arial', 14)).grid(row=0, sticky=W)
    Entry(ContactForm, textvariable=FIRSTNAME, font=('arial', 14)).grid(row=0, column=1)
    Label(ContactForm, text="Lastname", font=('arial', 14)).grid(row=1, sticky=W)
    Entry(ContactForm, textvariable=LASTNAME, font=('arial', 14)).grid(row=1, column=1)
    Label(ContactForm, text="Contact", font=('arial', 14)).grid(row=2, sticky=W)
    Entry(ContactForm, textvariable=CONTACT, font=('arial', 14)).grid(row=2, column=1)

    Button(ContactForm, text="Save", width=50, command=SubmitData).grid(row=3, columnspan=2, pady=10)

#============================FRAMES & UI===================================
Top = Frame(root, bd=1, relief=SOLID)
Top.pack(side=TOP)
Mid = Frame(root, bg="#6666ff")
Mid.pack(side=TOP)
MidLeft = Frame(Mid)
MidLeft.pack(side=LEFT, pady=10)
MidRight = Frame(Mid)
MidRight.pack(side=RIGHT, pady=10)
TableMargin = Frame(root)
TableMargin.pack(side=TOP)

Label(Top, text="Contact Management System", font=('arial', 16), width=500).pack(fill=X)

Button(MidLeft, text="+ ADD NEW", bg="#66ff66", command=AddNewWindow).pack()
Button(MidRight, text="DELETE", bg="red", command=DeleteData).pack(side=RIGHT)

scrollbarx = Scrollbar(TableMargin, orient=HORIZONTAL)
scrollbary = Scrollbar(TableMargin, orient=VERTICAL)
tree = ttk.Treeview(TableMargin, columns=("MemberID", "Firstname", "Lastname", "Contact"), height=400, selectmode="extended", yscrollcommand=scrollbary.set, xscrollcommand=scrollbarx.set)
scrollbary.config(command=tree.yview)
scrollbarx.config(command=tree.xview)
scrollbary.pack(side=RIGHT, fill=Y)
scrollbarx.pack(side=BOTTOM, fill=X)
tree.heading('MemberID', text="MemberID", anchor=W)
tree.heading('Firstname', text="Firstname", anchor=W)
tree.heading('Lastname', text="Lastname", anchor=W)
tree.heading('Contact', text="Contact", anchor=W)
tree.column('#0', stretch=NO, minwidth=0, width=0)
tree.column('#1', stretch=NO, minwidth=0, width=0)
tree.column('#2', stretch=NO, minwidth=0, width=120)
tree.column('#3', stretch=NO, minwidth=0, width=120)
tree.column('#4', stretch=NO, minwidth=0, width=120)
tree.pack()
tree.bind('<Double-Button-1>', OnSelected)

#============================INITIALIZATION==============================
if __name__ == '__main__':
    Database()
    root.mainloop()
